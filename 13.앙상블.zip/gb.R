m <- 10
y <- rep(-1L,m)
y[c(1,2,3,5,8)] <- 1L

d1 <- rep(0.1,m)
h1 <- rep(-1,m); h1[c(5,8)] <- 1
er1 <- 0.3
alpha1 <- 1/2*log((1-er1)/er1)

wm1 <- exp(-alpha1*y*h1) # exponential of weighted margin
z1 <- sum(d1*wm1) # sum of weighted margin

round(rbind(y,d1,wm1,d1*wm1,sign(alpha1*h1)),2)

# round 2
d2 <- d1*wm1/z1
h2 <- rep(1,m); h2[c(4,10)] <- -1
er2 <- sum(d2[(h2*y)<01])
alpha2 <- 1/2*log((1-er2)/er2)

wm2 <- exp(-alpha2*y*h2) # exponential of weighted margin
z2 <- sum(d2*wm2) # sum of weighted margin

# round 3
d3 <- d2*wm2/z2
h3 <- rep(1,m); h3[c(5,6,7,8,9,10)] <- -1; 
er3 <- sum(d3[(h3*y)<0])
alpha3 <- 1/2*log((1-er3)/er3)

wm3 <- exp(-alpha3*y*h3) # exponential of weighted margin
z3 <- sum(d3*wm3) # sum of weighted margin

tmp <- rbind(y,d1,sign(alpha1*h1),wm1,d1*wm1)
tmp <- rbind(tmp,d2,sign(alpha2*h2),wm2,d2*wm2)
tmp <- rbind(tmp,d3,sign(alpha3*h3),wm3,d3*wm3)

round(tmp,2)

library(xtable)
xtable(tmp,digits=2)

####















#